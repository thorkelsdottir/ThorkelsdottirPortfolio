<div class="menu-button2">
  <span class="myNavmenu2">
    <b>menu</b>
  </span>
</div>
