<div class="menu-button">
  <span class="myNavmenu">
    <b>menu</b>
  </span>
</div>
