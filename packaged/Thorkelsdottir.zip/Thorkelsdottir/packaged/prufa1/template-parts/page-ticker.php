<div class="frontpageUndertitle">
  <h2>Multidisciplinary</h2>
  <div class="line"></div>
  <div class="scroller">
    <div class="inner">
      <span class='ticker'>
        <span class='ticker_item first_ticker current_ticker'>Design Studio</span>
        <span class='ticker_item'>Web Development</span>
        <span class='ticker_item'>Photography</span>
        <span class='ticker_item'>User Experience</span>
        <span class='ticker_item'>Graphic Design</span>
        <span class='ticker_item'>Product Design</span>
        <span class='ticker_item'>Idea Makers</span>
      </span>
    </div>
  </div>
</div>
