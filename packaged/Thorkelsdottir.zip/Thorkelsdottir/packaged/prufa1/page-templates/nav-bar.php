
<p><a class="menu-icon" data-toggle="exampleModal8">Click me for a full-screen modal</a></p>

<div class="full reveal" id="exampleModal8" data-reveal>
  <p>OH I'M SO FUUUUL</p>
  <img src="http://placekitten.com/1920/1280" alt="Intropsective Cage">
  <button class="close-button" data-close aria-label="Close reveal" type="button">
    <span aria-hidden="true">&times;</span>
  </button>
</div>



<nav>
  <div class="menu-icon">
    <a data-toggle="thork-menu"><img src="<?php echo get_template_directory_uri().  "/assets/images/icons/menu.svg"; ?>" alt="menu" height="30"/></a>
  </div>

  <div class="full reveal" id="thork-menu" data-reveal>
    <ul class="menu vertical">
      <li><a href="index.html">WE BELIEVE</a></li>
      <li><a href="index.html">OUR WORK IS</a></li>
      <li><a href="index.html">CREATIVE</a></li>
    </ul>
    <button class="close-button" data-close aria-label="Close reveal" type="button">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
</nav>
