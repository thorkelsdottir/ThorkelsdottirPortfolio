<?php
/*
Template Name: Case Study
*/
get_header(); ?>



  <?php get_template_part('template-parts/page-menu-black'); ?>
  <?php get_template_part('template-parts/page-title-logo'); ?>
  <?php get_template_part('template-parts/page-ticker-vertical'); ?>






<?php get_footer(); ?>
