<?php
/*
Template Name: Creative
*/
get_header(); ?>

<?php get_template_part('template-parts/page-menu-white'); ?>
<?php get_template_part('template-parts/page-title-logo-white'); ?>

  <div class="bigPicoverlay"></div>
  <div class="bigPic scroll">
    <img src="<?php echo get_template_directory_uri().  "/assets/images/bigPic.jpg"; ?>" alt="" />
  </div>
  <div class="textOver " id="page-wrap">
    <!-- <div class="post">
    //geyma til síðar
      <h2 class="texti1 scroll">
        "Ljósbrot í vatni
        litar vitund mína
        hreyfingar handa
        færa mig fram"
        </h2>
        <h2 class="texti2 scroll">
        "Ljósbrot í vatni
        litar vitund mína
        hreyfingar handa
        færa mig fram"
        </h2>
    </div> -->
    <div class="pageTitleCreative scroll">
      <h1>Follow your bliss and the universe will open doors where there were only walls</h1>
    </div>
  </div>
  <div class='icon-scroll'><div/>

<?php get_footer(); ?>
