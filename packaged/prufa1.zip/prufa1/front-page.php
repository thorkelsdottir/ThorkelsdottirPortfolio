<?php get_header(); ?>
<?php get_template_part('page-templates/page-frontpage'); ?>
<?php get_template_part('template-parts/page-ticker'); ?>
<?php get_footer(); ?>
