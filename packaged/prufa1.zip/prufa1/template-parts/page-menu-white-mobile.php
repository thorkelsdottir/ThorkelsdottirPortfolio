<div class="menu-button3">
  <span class="myNavmenu">
    <b>menu</b>
  </span>
</div>
