<div class="menu-button">
  <span class="myNavmenu2">
    <b>menu</b>
  </span>
</div>
